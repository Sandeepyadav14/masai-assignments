package SingleTable.Bean;

public enum Subscription {
    ACTIVE,
    INACTIVE
}
