package JoinedTable.Bean;

public enum Subscription {
    ACTIVE,
    INACTIVE
}
